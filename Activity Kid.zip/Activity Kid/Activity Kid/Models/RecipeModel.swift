
//  RecipeModel.swift
//  Activity-Kids
//
//  Created by Julissa Salinas on 4/23/22.
//

import Foundation
import SwiftUI

enum Category: String, CaseIterable, Identifiable {
    var id: String { self.rawValue }
    
    case breakfast = "Breakfast"
    case soup = "Soup"
    case salad = "Salad"
    case appetizer = "Appetizer"
}

struct Recipe: Identifiable {
    let id = UUID()
    let name: String
    let image: String
    let descriptions: String
    let ingredients: String
    let directions: String
    let category: Category.RawValue
    let datePublished: String
    let url: String
}
    
extension Recipe {
    static let all: [Recipe] = [
        Recipe(
            name: "Carrot Soup",
            image: "https://media.istockphoto.com/photos/happy-smiling-africanamerican-child-girl-yellow-background-picture-id1168369629?k=20&m=1168369629&s=612x612&w=0&h=cOqiMS2ibSZPXOTy6OkRZrGJRUNmIKkv89iVO4TjW3M=",
            descriptions: "description of carrot soup",
            ingredients: "carrot ingreditants",
            directions: "carrot directions",
            category: "Soup",
            datePublished: "08-19-2022",
            url: "https://www.google.com"
        ),
        Recipe(
            name: "Kale, apple, salad",
            image: "salad picture",
            descriptions: "description of salad",
            ingredients: "salad ingreditants",
            directions: "salad directions",
            category: "Salad",
            datePublished: "06-29-21",
            url: "https://www.facebook.com"
        ),
        Recipe(
            name: "egg sandwich",
            image: "https://t3.ftcdn.net/jpg/02/88/01/98/360_F_288019837_M5b7qGaXpmMfWOSgso53PWQu9rIdg5et.jpg",
            descriptions: "egg description",
            ingredients: "egg ingreditants",
            directions: "egg directions",
            category: "Breakfast",
            datePublished: "04-23-22",
            url: "https://www.google.com"
        )
    ]
}
