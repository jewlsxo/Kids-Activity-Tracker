//
//  Activity_KidApp.swift
//  Activity Kid
//
//  Created by Julissa Salinas on 4/25/22.
//

import SwiftUI

@main
struct Activity_KidApp: App {
    
    @StateObject var recipesViewModel = RecipesViewModel()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(recipesViewModel)
        }
    }
}
