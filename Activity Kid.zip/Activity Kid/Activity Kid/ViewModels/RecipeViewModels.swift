//
//  RecipesViewModel.swift
//  Activity-Kids
//
//  Created by Julissa Salinas on 4/24/22.
//

import Foundation

class RecipesViewModel: ObservableObject {
    @Published private(set) var recipes: [Recipe] = []
    
    init() {
        recipes = Recipe.all
    }
    
    func addRecipe(recipe: Recipe) {
        recipes.append(recipe)
    }
    
}
