//
//  Health Info.swift
//  Activity Trackers
//
//  Created by Julissa Salinas on 4/1/22.
//

import SwiftUI

struct Health_Info: View {
    @State var prescription = ""
    @State var allergies = ""
    @State var diagnosed = ""
    @State var doctors = ""
    @State var lastCheckUp = ""
    var body: some View {
        NavigationView {
            VStack {
                Form {
                    Section {
                        TextField("Prescriptions: ", text: $prescription)
                        TextField("Allergies: ", text: $allergies)
                        TextField("Diagnosed: ", text: $diagnosed)
                        TextField("Doctors Name: ", text: $doctors)
                        TextField("Last Check Up: ", text: $lastCheckUp)
                        }
                    Button("Submit") {

                    }
                    }
            .navigationTitle("Health Information")
                }
            }
        }
    }

struct Health_Info_Previews: PreviewProvider {
    static var previews: some View {
        Health_Info()
    }
}
