//
//  HomeScreen.swift
//  Activity Trackers
//
//  Created by Julissa Salinas on 4/15/22.
//

import SwiftUI

struct HomeScreen: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct HomeScreen_Previews: PreviewProvider {
    static var previews: some View {
        HomeScreen()
    }
}
